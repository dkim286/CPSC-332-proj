<?php
include('header.php');
?>
<div class="container">
  <h4>Team members</h4>
  <address>
      <strong>Preet Desai</strong>
      <br>
      <a href="https://github.com/preetdesai025" target="_blank" rel"noopener noreferrer">
        https://github.com/preetdesai025
      </a>
  </address>
  <address>
      <strong>Patrick Mahoney</strong>
      <br>
    <a href="https://github.com/patrickmahoney11" target="_blank" rel="noopener noreferrer">
        https://github.com/patrickmahoney11
    </a>
  </address>
  <address>
      <strong>Austin Kim</strong>
      <br>
    <a href="https://github.com/dkim286" target="_blank" rel="noopener noreferrer">
        https://github.com/dkim286
    </a> 
  </address>
</div>
